# Geralt Bannerlord Compatibility Patch

Recovered compatibility repair for **MixMashMagicArmorPack**, verified on 5 November 2026. This is a limited repair, not a standalone Geralt mod or a general update of the armor pack.

## Required source

Supply your own legally obtained, extracted copy of:

`Mixed weapon package-Magic version-7544-V1-1-6-1733968879.rar`

Archive SHA-256: `2F58410AFCA1A4BDBE3B4BADF782B4BB0A88D055606F260E571773EE40A90F3C`.

The filename identifies V1.1.6; the internal manifest declares v1.0.0. The 23 extracted file hashes in `expected-original.json` are authoritative. Modified configuration files and other releases are deliberately rejected. Use a clean source copy and keep personal settings separately.

Candidate source: https://www.nexusmods.com/mountandblade2bannerlord/mods/7544?tab=files&file_id=44775

The public page did not expose enough file metadata or a downloadable source during this investigation. Current download availability, redistribution permissions and the exact association of local archive bytes with Nexus file ID 44775 could not be verified. The local archive's relationship to the working installation was established independently: 22 of its 23 files match exactly; the remaining file differs only by the compatibility registration described below.

No original model, texture, mod DLL, Harmony DLL, PDB, TPAC or source archive is included. The only DLL shipped is the separately authored 12,800-byte compatibility shim, recovered verbatim from the working setup. Its recovered C# source is included for inspection. Obtain original assets and dependencies yourself.

## Environment and scope

Observed installation: **Bannerlord v1.4.8, runtime build 119303**, Steam build 24573425. The Native manifest and an existing game log confirm the game version/build. Tests used the installed assemblies. Install **Bannerlord.Harmony** separately and load it before MixMashMagicArmorPack. The observed Harmony module is v2.4.2.248 (assembly 2.4.2.0). Other versions have not been verified.

The shim loads before the original armor submodule. It adapts one obsolete module-list call in OnGameStart to GetActiveModules(), restores the original three string literals required after Harmony transpilation, and adapts one obsolete OnMissionTick wielded-item call to the current primary/offhand APIs. The protected original armor DLL is unchanged on disk.

**Known limitations:** inspection recorded other obsolete API signatures in optional trader and weapon flame-effect paths: LocationCharacter construction, OpenScreenAsTrade, MatrixFrame construction and GetWeaponEntityFromEquipmentSlot. Another wield helper in the flame-effect path is unpatched. These paths may still fail. This package reproduces the existing working repair and does not claim complete mod compatibility.

## Install

1. Close Bannerlord. Extract this patch ZIP to a separate folder, outside the mod.
2. Install the original mod and Bannerlord.Harmony yourself. Keep the source archive.
3. Open Windows PowerShell in the extracted patch folder and run:

   `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Patch.ps1`

4. Enter the full path to your **MixMashMagicArmorPack** folder when prompted. Paste paths containing spaces without surrounding quotes. The script does not silently choose an installation.
5. The script verifies all 23 original files and its payload by SHA-256 before writing. An incompatible, missing, changed, already-patched or linked/junction target is rejected. `-Action Verify` performs checks without writing. Hashing the large assets may take time.
6. A `_GeraltCompatibilityBackup_<timestamp>_<id>` folder is created inside the chosen mod before changes. Keep the printed backup path. The only original file replaced is `SubModule.xml`. The only added runtime file is `bin\Win64_Shipping_Client\MixMashBannerlord148Compatibility.dll`.
7. Enable Harmony before MixMashMagicArmorPack in the launcher. Do not apply twice. The shim also checks the original armor DLL hash at runtime and rejects unexpected bytes.

To supply the target explicitly:

`powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Patch.ps1 -ModPath 'D:\SteamLibrary\steamapps\common\Mount & Blade II Bannerlord\Modules\MixMashMagicArmorPack'`

An access-denied failure under Program Files requires appropriate write access to the chosen mod folder. The patch does not change permissions, automatically elevate, or change the global execution policy. Unrelated extra files are preserved; the known 23 source files must match exactly.

## Roll back

Close Bannerlord, then run:

`powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Patch.ps1 -Action Restore`

Enter the same mod folder and the saved backup folder, or pass `-ModPath` and `-BackupPath` explicitly. Restore verifies the backup, current XML and installed shim before changing anything. If either patched runtime file has since changed, it stops. It restores the original XML and removes only the exact shim added by this patch. The backup remains.

Manual recovery after a filesystem/permission interruption: close the game; copy `SubModule.xml` from the printed backup back into the mod root. Remove only `bin\Win64_Shipping_Client\MixMashBannerlord148Compatibility.dll` if its SHA-256 is `526E7B915EE87B6C18DD8B94D2508C7A2C4BC7A8E4CF433139C3192DAA7CED0A`. Preserve original assets, the original armor DLL, ModuleData, other mods and saves. Original hashes are in `expected-original.json`.

## Verification and limits

The patch was applied to a full temporary extraction outside the live installation. All 24 resulting runtime files matched the working installation by SHA-256. Rollback restored all 23 original hashes. Tests rejected altered source, corrupted payload, corrupted backup, changed installed shim and repeated application without changing target files. Verify mode was read-only.

The recovered C# source was rebuilt separately and matched the working shim's signatures, references, constants, field data and IL, ignoring compiler-generated build GUIDs. All 74 shim method/field references resolved against installed assemblies. An isolated probe on the original decrypted OnMissionTick confirmed 62 instructions, exactly one helper-operand replacement, preservation of other instructions/labels/exception markers, and rejection of zero/two matching calls.

Geralt head definitions `great_head_c` and `great_head_d` remain present. All 15 ModuleData files and all three TPAC packages are byte-identical to the original. Thus the supplied Geralt face/hair/beard asset data, Kaer Morhen armor and Witcher sword data are preserved unchanged. Their rendered appearance was **not inspected in-game** during this task.

No game session was launched. No live mod, save, load order or game configuration was changed. The reference installation's working status was supplied by the user; file/IL checks do not prove full gameplay compatibility. Nothing was uploaded or published. See EVIDENCE.md for provenance and hashes. Building the C# source requires your own game/Harmony assemblies and a suitable C# compiler.
