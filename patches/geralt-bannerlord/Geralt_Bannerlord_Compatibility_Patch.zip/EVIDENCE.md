# Evidence record

Date: 2026-11-05 (Europe/Istanbul). File paths are relative to the mod.

## Provenance

The August crash clue belongs to an unrelated Nexus 3780 weapon pack XML repair; those changes are excluded. Applicable Codex records are the 15 October sessions 01a13d41-3c29-7b02-9d1f-8fe920e9166b and 01a13d42-5477-76e0-b733-c8cd84adb0a3. A dated repair backup retained original armor DLL/manifest, shim source, build script, V3 staging evidence and probe source. Its original manifest and DLL match the local RAR. Its V3 shim hash matches the working installation.

The C:\kaerMorhen mod folder and MixMashMagicArmorPack.zip both match all 24 working files and are not pristine sources. The original RAR is 2,069,932,353 bytes; SHA-256: 2F58410AFCA1A4BDBE3B4BADF782B4BB0A88D055606F260E571773EE40A90F3C. Extracted original: 23 files / 2,377,195,734 bytes. Working mod: 24 files / 2,377,209,010 bytes.

Game evidence: Native v1.4.8; existing rgl_log_75040.txt reports runtime build 119303; Steam appmanifest_261550.acf reports build 24573425.

## Changed runtime files

| Path | Original SHA-256 | Patched SHA-256 |
|---|---|---|
| SubModule.xml | 15C5877D6D905713A36E10DFE5B57A6A28FCD5303F4106ABA21A1E6A4357E3DE | 61EC909F6794EF0FC10907F56B2A4092A91AD8577E514029BA9CAAFA94DA9483 |
| bin\Win64_Shipping_Client\MixMashBannerlord148Compatibility.dll | ABSENT | 526E7B915EE87B6C18DD8B94D2508C7A2C4BC7A8E4CF433139C3192DAA7CED0A |

SubModule.xml gains only the Harmony dependency and a compatibility submodule before the original submodule. Mixed line endings are reproduced exactly. No personal settings or Castles Restored changes are included.

## Unchanged original binaries and assets

| Path | SHA-256 |
|---|---|
| AssetPackages\pack0.tpac | 33D8CCF983C0051C4F3A127C286A13E1AF99AADD74E322950AAD8463F3731539 |
| AssetPackages\pack1.tpac | 670B3943CB9F7DA89CAF42D6FB36DE570D997B9F1BE284A2CBA616F38B5CEFCD |
| bin\Win64_Shipping_Client\0Harmony.dll | 94B63EE6A2BE0EA100335638A55764A207DC2BF75E7270C05A28DD26647828A3 |
| bin\Win64_Shipping_Client\MixMashChineseFantasyArmorPack.dll | 182BFA0A892B992B167086FDE4977E52DE4108521FE5C8F04DB060EDC4CB01FA |
| DsAssetPackages\pack0.tpac | A50D8EC2E8653AC2710AD4D16AB7A852490E764EFCD64C640415DA7729DD2A8B |

All 15 ModuleData files, Config.json and original PDB also match. All source file hashes are in expected-original.json. Geralt items: great_head_c/d. Kaer Morhen: Kaer_morhenhujia, Kaer_morhenhutui, Kaer_morhenhushou. Witcher swords include hunvjian (Lake Lady's Sword/Aerondight) and xiongtaojian2 (Bear Sword).

## Current tests

PASS: changed source rejected without writes; corrupt payload rejected without writes; Verify read-only; denied XML replacement rolls back the added shim and preserves original files/backup; full apply reproduces all 24 active hashes; corrupt backup rejected without writes; changed installed shim rejected without writes; double apply rejected without writes; restore reproduces all 23 original hashes. Backup retained.

Source rebuild: matching references, type/field/method signatures, constant field bytes, locals, IL and exception handlers after normalizing only compiler-generated PrivateImplementationDetails GUID. All 74 shim method/field references resolve. Original decrypted mission-tick probe passes. No game/rendering test performed; known optional trader/flame-effect gaps remain.

Nexus availability and exact local-archive-to-file-ID 44775 mapping remain unverified. No permission to redistribute original assets was assumed.
